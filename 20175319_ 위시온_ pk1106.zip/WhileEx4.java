package pk1106;

public class WhileEx4 {
	int cnt, sum, data, data1, data2, data3;

	void eInput(int a, int b, int c) {
		data = a;
		data1 = b;
		data2 = c;
		data3 = a;
	}

	void eSumCnt() {

		int cnt = 0, sum = 0;

		while (data <= data1) {
			if (data % data2 == 0) {
				cnt++;
				sum += data;
			}
			data++;
		}
	}

	void ePrintData() {
		int icnt = 0;

		data = data3;
		while (data <= data1) {
			if (data % data2 == 0) {
				System.out.format("%-7d", data);
				icnt++;
				sum += data;
				if (icnt % 7 == 0) {
					System.out.println("");
				}
			}
			data++;
		}
		cnt = icnt;
	}

	void ePrintSumCnt() {
		System.out.println("\n" + data2 + "�� ����� ���� : " + cnt + "\n" + data2
				+ "�� ����� �� : " + sum);
	}

	public static void main(String args[]) {
		WhileEx4 obj = new WhileEx4();

		obj.eInput(3, 500, 7);
		obj.eSumCnt();
		obj.ePrintData();
		obj.ePrintSumCnt();
	}
}
