package pk1106;

public class WhileEx5 {
	int cnt, sum, start, center, start1, xxxx, line;

	void eInput(int a, int b, int c, int d) {
		start = a;
		center = b;
		xxxx = c;
		start1 = a;
		line = d;

	}

	void eSumCnt() {

		int cnt = 0, sum = 0;

		while (start <= center) {
			if (start % xxxx == 0) {
				cnt++;
				sum += start;
			}
			start++;
		}
	}

	void ePrintData() {
		int icnt = 0;

		start = start1;
		while (start <= center) {
			if (start % xxxx == 0) {
				System.out.format("%-7d", start);
				icnt++;
				sum += start;
				if (icnt % line == 0) {
					System.out.println("");
				}
			}
			start++;
		}
		cnt = icnt;
	}

	void ePrintSumCnt() {
		System.out.println("\n" + xxxx + "�� ����� ���� : " + cnt + "\n" + xxxx
				+ "�� ����� �� : " + sum);
	}

	public static void main(String args[]) {
		WhileEx5 obj = new WhileEx5();

		obj.eInput(1, 100, 5, 7);
		obj.eSumCnt();
		obj.ePrintData();
		obj.ePrintSumCnt();
	}
}
