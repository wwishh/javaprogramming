package pk1106;

public class WhileEx2 {
	int cnt, sum;

	void eSumCnt() {
		int i;
		int cnt = 0, sum = 0;

		i = 1;
		while (i <= 100) {
			if (i % 5 == 0) {
				cnt++;
				sum += i;
			}
			i++;
		}
	}

	void ePrintData() {
		int i;
		int icnt = 0;

		i = 1;
		while (i <= 100) {
			if (i % 5 == 0) {
				System.out.format("%-4d", i);
				icnt++;
				sum += i;
				if (icnt % 7 == 0) {
					System.out.println("");
				}
			}
			i++;
		}
		cnt = icnt;
	}

	void ePrintSumCnt() {
		System.out.println("\n5�� ����� ���� :" + cnt + " \n5�� ����� �� :" + sum);
	}

	public static void main(String args[]) {
		WhileEx2 obj = new WhileEx2();

		obj.eSumCnt();
		obj.ePrintData();
		obj.ePrintSumCnt();
	}
}
