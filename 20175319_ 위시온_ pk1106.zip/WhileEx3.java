package pk1106;

public class WhileEx3 {
	int cnt, sum, data;

	void eInput(int a) {
		data = a;
	}

	void eSumCnt() {
		int i;
		int cnt = 0, sum = 0;

		i = 1;
		while (i <= 100) {
			if (i % data == 0) {
				cnt++;
				sum += i;
			}
			i++;
		}
	}

	void ePrintData() {
		int i;
		int icnt = 0;

		i = 1;
		while (i <= 100) {
			if (i % data == 0) {
				System.out.format("%-4d", i);
				icnt++;
				sum += i;
				if (icnt % 7 == 0) {
					System.out.println("");
				}
			}
			i++;
		}
		cnt = icnt;
	}

	void ePrintSumCnt() {
		System.out.println("\n" + data + "�� ����� ���� : " + cnt + "\n" + data
				+ "�� ����� �� : " + sum);
	}

	public static void main(String args[]) {
		WhileEx3 obj = new WhileEx3();

		obj.eInput(8);
		obj.eSumCnt();
		obj.ePrintData();
		obj.ePrintSumCnt();
	}
}
