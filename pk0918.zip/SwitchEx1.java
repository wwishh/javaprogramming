package pk0918;

public class SwitchEx1 {
	public static void main(String[] args) {
		int data;
		char c;

		data=78;
				
		switch(data/10)
		{
			case 10:
			case 9: c='A'; break;
			case 8: c='B'; break;
			case 7: c='C'; break;
			case 6: c='D'; break;
			default :  	c = 'F';
		}
		System.out.println("����� ������ "  + c +"�Դϴ�.");
	}
}
