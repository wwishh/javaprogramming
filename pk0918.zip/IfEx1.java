package pk0918;

public class IfEx1 {
	public static void main(String[] args) {
		int su1 = 51;
		String str = "50�̸�";

		if(su1 >= 52)
			str = "50�̻�";

		System.out.println(str+"�Դϴ�.");
	}
}
