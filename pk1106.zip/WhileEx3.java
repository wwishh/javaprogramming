package pk1106;

public class WhileEx3 {

	.... �� �κ��� �ϼ��ϼ���...

	public static void main(String[] args) {
		WhileEx3 obj = new WhileEx3();
		
		obj.eInput(8);
		obj.eSumCnt();
		obj.ePrintData();
		obj.ePrintSumCnt();
	}
}
