package pk1106;

public class WhileEx5 {

	.... �� �κ��� �ϼ��ϼ���...
	
	public static void main(String[] args) {
		WhileEx5 obj = new WhileEx5();
		
		obj.eInput(1, 100, 5, 7);
		obj.eSumCnt();
		obj.ePrintData();
		obj.ePrintSumCnt();
	}
}
