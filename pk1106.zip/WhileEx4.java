package pk1106;

public class WhileEx4 {

	.... �� �κ��� �ϼ��ϼ���...
	
	public static void main(String[] args) {
		WhileEx4 obj = new WhileEx4();
		
		obj.eInput(1, 100, 7);
		obj.eSumCnt();
		obj.ePrintData();
		obj.ePrintSumCnt();
	}
}
