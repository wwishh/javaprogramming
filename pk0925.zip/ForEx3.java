package pk0925;

public class ForEx3 {
	public static void main(String[] args) {
		int i;

		for(i = 1 ; i <= 100 ; i++){
			if(i%2 != 0)
				System.out.print(i+"  ");
		}
	}
}
