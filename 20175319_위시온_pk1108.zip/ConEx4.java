package pk1108;

public class ConEx4 {
	int i, j;
	int cnt = 0, sum = 0;

	ConEx4(int a) {
		j = a;
	}

	void eSumCnt() {
		i = 1;
		while (i <= 100) {
			if (i % j == 0) {
				cnt++;
				sum += i;
			}
			i++;
		}
	}

	void ePrintData() {
		int icnt = 0;
		int cnt=0, sum=0;
		i = 1;
		while (i <= 100) {
			if (i % j == 0) {
				System.out.format("%-4d", i);
				icnt++;
				sum += i;
				if (icnt % 7 == 0) {
					System.out.println();
				}
			}
			i++;
		}
		cnt =icnt;
	}

	void ePrintSumCnt() {
		System.out.println("\n5�� ����� ����: " + cnt);
		System.out.println("5�� ����� ��: " + sum);
	}

	public static void main(String args[]) {
		ConEx4 obj = new ConEx4(5);

		obj.eSumCnt();
		obj.ePrintData();
		obj.ePrintSumCnt();
	}

}
