package pk1108;

public class ConEx5 {
	int cnt, sum, d1, d2, d3, d4;

	ConEx5(int a, int b, int c, int d) {
		d1 = a;
		d2 = b;
		d3 = c;
		d4 = d;
	}

	void eSumCnt() {
		int i;
		int cnt=0, sum=0;

		i = d1;
		while (i <= d2) {
			if (i % d3  == 0) {
				cnt++;
				sum += i;
			}
			i++;
		}
	}

	void ePrintData() {
		int i;
		int icnt = 0;

		i = d1;
		while (i <= d2) {
			if (i % d3 == 0) {
				System.out.format("%-4d", i);
				icnt++;
				sum += i;
				if (icnt % d4 == 0) {
					System.out.println("");
				}
			}
			i++;
		}
		cnt = icnt;
	}

	void ePrintSumCnt() {
		System.out.println("\n" + d3 + "�� ����� ���� : " + cnt + "\n" + d3
				+ "�� ����� �� : " + sum);
	}

	public static void main(String args[]) {
		ConEx5 obj = new ConEx5(10, 100, 8, 10);

		obj.eSumCnt();
		obj.ePrintData();
		obj.ePrintSumCnt();
	}
}

