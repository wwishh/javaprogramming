package pk1206;

import java.util.Scanner;

public class T3 {

	String name;
	int data1;
	int data2;
	int data3;
	int sum = 0, avg;
	char c;

	void data() {
		Scanner sc = new Scanner(System.in);
		name = sc.nextLine();
		data1 = sc.nextInt();
		data2 = sc.nextInt();
		data3 = sc.nextInt();
	}

	void eSum() {
		sum = data1 + data2 + data3;
	}

	void eAvg() {
		avg = sum / 3;
	}

	void Score() {
		if (avg >= 90 && avg <= 100) {
			c = 'A';
		} else if (avg >= 80 && avg < 90) {
			c = 'B';
		} else if (avg >= 70 && avg < 80) {
			c = 'C';
		} else if (avg >= 60 && avg < 70) {
			c = 'D';
		} else {
			c = 'F';
		}
	}

	void print() {
		System.out.println("[" + name + "]���� ������[" + data1 + "][" + data2
				+ "][" + data3 + "]�̰�,\n����[" + sum + "] ���[" + avg + "] ������["
				+ c + "]�Դϴ�.");
	}

	public static void main(String args[]) {
		T3 obj1 = new T3();

		obj1.data();
		obj1.eSum();
		obj1.eAvg();
		obj1.Score();
		obj1.print();
	}
}