package pk1206;

import java.util.Scanner;

public class T2 {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		String name = sc.nextLine();
		int data1 = sc.nextInt();
		int data2 = sc.nextInt();
		int data3 = sc.nextInt();

		int sum = 0, avg;
		char c;

		sum = data1 + data2 + data3;
		avg = sum / 3;

		if (avg >= 90 && avg <= 100) {
			c = 'A';
		} else if (avg >= 80 && avg < 90) {
			c = 'B';
		} else if (avg >= 70 && avg < 80) {
			c = 'C';
		} else if (avg >= 60 && avg < 70) {
			c = 'D';
		} else {
			c = 'F';
		}

		System.out.println("[" + name + "]���� ������[" + data1 + "][" + data2
				+ "][" + data3 + "]�̰�,\n����[" + sum + "] ���[" + avg + "] ������["
				+ c + "]�Դϴ�.");
	}

}
