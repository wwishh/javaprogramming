package pk1206;

import java.util.Scanner;

interface X1 {
	void W();
}

class S1 implements X1 {
	public void W() {
		Scanner sc = new Scanner(System.in);
		String name;
		int data1;
		int data2;
		int data3;
		name = sc.nextLine();
		data1 = sc.nextInt();
		data2 = sc.nextInt();
		data3 = sc.nextInt();
		int sum = 0, avg;
		char c;

		sum = data1 + data2 + data3;
		avg = sum / 3;

		if (avg >= 90 && avg <= 100) {
			c = 'A';
		} else if (avg >= 80 && avg < 90) {
			c = 'B';
		} else if (avg >= 70 && avg < 80) {
			c = 'C';
		} else if (avg >= 60 && avg < 70) {
			c = 'D';
		} else {
			c = 'F';
		}

		System.out.println("[" + name + "]���� ������[" + data1 + "][" + data2
				+ "][" + data3 + "]�̰�,\n����[" + sum + "] ���[" + avg + "] ������["
				+ c + "]�Դϴ�.");

	}
}

public class T5 {
	public static void main(String args[]) {
		S1 obj1 = new S1();

		obj1.W();

	}
}