package pk1206;

import java.util.Scanner;

class Q1 {
	Scanner sc = new Scanner(System.in);
	String name;
	int data1;
	int data2;
	int data3;
	int sum = 0, avg;
	char c;
}

class Q2 extends Q1 {
	void data(){
		Scanner sc = new Scanner(System.in);
		 name = sc.nextLine();
		 data1 = sc.nextInt();
		 data2 = sc.nextInt();
		 data3 = sc.nextInt();
	}
	void eSum() {
	
		sum = data1 + data2 + data3;
	}
	void eAvg(){
		avg = sum / 3;
	}

	void Score() {
		if (avg >= 90 && avg <= 100) {
			c = 'A';
		} else if (avg >= 80 && avg < 90) {
			c = 'B';
		} else if (avg >= 70 && avg < 80) {
			c = 'C';
		} else if (avg >= 60 && avg < 70) {
			c = 'D';
		} else {
			c = 'F';
		}
	}

	void print() {
		System.out.println("[" + name + "]���� ������[" + data1 + "][" + data2
				+ "][" + data3 + "]�̰�,\n����[" + sum + "] ���[" + avg + "] ������["
				+ c + "]�Դϴ�.");
	}
}

public class T4 {
	public static void main(String args[]) {
		Q2 obj1 = new Q2();
		
		obj1.data();
		obj1.eSum();
		obj1.eAvg();
		obj1.Score();
		obj1.print();
	}
}
