package pk1206;

public class T1 {
	public static void main(String args[]) {
		int sum = 0, avg;
		char c;

		String name = args[0];
		int data1 = Integer.parseInt(args[1]);
		int data2 = Integer.parseInt(args[2]);
		int data3 = Integer.parseInt(args[3]);

		sum = data1 + data2 + data3;
		avg = sum / 3;

		if (avg >= 90 && avg <= 100) {
			c = 'A';
		} else if (avg >= 80 && avg < 90) {
			c = 'B';
		} else if (avg >= 70 && avg < 80) {
			c = 'C';
		} else if (avg >= 60 && avg < 70) {
			c = 'D';
		} else {
			c = 'F';
		}

		System.out.println("[" + name + "]���� ������[" + data1 + "][" + data2
				+ "][" + data3 + "]�̰�,\n����[" + sum + "] ���[" + avg + "] ������["
				+ c + "]�Դϴ�.");
	}

}
