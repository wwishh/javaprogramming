package pk1122;

class Parent2 {
	String msg = "ParentŬ����";
	public String getMsg(){
		return msg;
	}
}

class Child2 extends Parent2{

	String msg = "ChildŬ����";
	public String getMsg(){
		return msg;
	}
}

public class OverridingEx {
	public static void main(String[] args){

		Child2 cd = new Child2();
		System.out.println("cd : "+cd.getMsg());

		Parent2 pt = new Child2();
		System.out.println("pt : "+pt.getMsg());
	}
}