package pk1025;

public class ObjExam0 {
	public static void main(String[] args){
		String name = "������";

		System.out.println("�̸� : " + name);
	}
}
