package pk0911;

public class HiJava {
	public static void main(String args[])
	{
		System.out.println("Hi Java~~");
	}
}
