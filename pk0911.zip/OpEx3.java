package pk0911;

public class OpEx3 {
	public static void main(String args[])
	{
		int a=7, b=0;
		int c;
		
		c = a & b;
		System.out.println("a & b�� ���� : " + c);

		c = a | b;
		System.out.println("a | b�� ���� : " + c);
		
	}
}
