package pk0911;

public class FloatEx {
	public static void main(String args[])
	{
		float f = 3.4f;
		
		System.out.println("f�� ���� : " + f);
		
	}
}
