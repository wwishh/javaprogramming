package pk0911;

public class DoubleEx {
	public static void main(String args[])
	{
		double d = 3.4;
		
		System.out.println("d�� ���� : " + d);
		
	}
}
