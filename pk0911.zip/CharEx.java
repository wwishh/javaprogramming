package pk0911;

public class CharEx {
	public static void main(String args[])
	{
		int c = 'A';

		System.out.println("c�� ���� : " + (char)c);
	}
}
