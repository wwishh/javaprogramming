package pk0911;

public class ByteEx {
	public static void main(String args[])
	{
		byte b = 127;

		System.out.println("b�� ���� : " + b);
	}
}
