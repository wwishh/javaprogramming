package pk0927;

public class WhileEx7 {
	public static void main(String[] args) {
		int i;
		int c;
		
		c = Integer.parseInt(args[0]);
		
		i=1;
		while(i<=26)
		{
			System.out.print((char)c++ + " ");
			i++;
		}
	}  
}
