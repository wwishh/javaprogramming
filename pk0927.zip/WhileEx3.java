package pk0927;

public class WhileEx3 {
	public static void main(String[] args) {
		int i, cnt=0, sum=0;
		int data;
		int s, e;

		s= Integer.parseInt(args[0]); 
		e=Integer.parseInt(args[1]); 
		data =  Integer.parseInt(args[2]); 

		i=s;
		while(i <= e )
		{
			if(i%data == 0)
			{
				System.out.format("%-10d",i);
				cnt++;
				sum += i;
				if(cnt%7 == 0) 
					System.out.println();
			}
			i++;
		}
		System.out.println("\n" + data +"����� ������ = " + cnt);
		System.out.println("���� = " + sum);
	}
}
