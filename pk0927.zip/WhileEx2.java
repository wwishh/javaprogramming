package pk0927;

public class WhileEx2 {
	public static void main(String[] args) {
		int i, cnt=0, sum=0;
		int data;

		data = Integer.parseInt(args[0]);
		i=1;
		while(i <= 100)
		{
			if(i%data == 0)
			{
				//System.out.print(i+"  ");
				System.out.format("%-10d",i);
				cnt++;
				sum += i;
				if(cnt%7 == 0) 
					System.out.println();
			}
			i++;
		}
		System.out.println("\n" + data + " ����� ������ = " + cnt);
		System.out.println("���� = " + sum);
	}
}
