package pk0927;

public class WhileEx6 {
	public static void main(String[] args) {
		int i;
		char c='A';

		i=1;
		while(i<=26)
		{
			System.out.print(c++ + " ");
			i++;
		}
	}  
}
