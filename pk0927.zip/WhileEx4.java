package pk0927;

public class WhileEx4 {
	public static void main(String[] args) {
		int cnt=0, sum=0;
		int data;
		int s, e;

		s= Integer.parseInt(args[0]); 
		e=Integer.parseInt(args[1]); 
		data =  Integer.parseInt(args[2]); 

		while(s <= e )
		{
			if(s%data == 0)
			{
				System.out.format("%-10d",s);
				cnt++;
				sum += s;
				if(cnt%7 == 0) 
					System.out.println();
			}
			s++;
		}
		System.out.println("\n" + data +"����� ������ = " + cnt);
		System.out.println("���� = " + sum);
	}
}
