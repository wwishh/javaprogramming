package pk0913;

public class OpEx8 {
	public static void main(String args[])
	{
		int x, y;

		x=10;
		y=20;

	//	x=x+y;

		System.out.println("x�� y�� ���� = " + (x+y) + "�Դϴ�.");
	}
}
