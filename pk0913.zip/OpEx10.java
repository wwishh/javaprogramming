package pk0913;

public class OpEx10 {
	public static void main(String[] args) {
		String res = args[0];
		int data1 = Integer.parseInt(args[1]);
		int data2 = Integer.parseInt(args[2]);
		int data3 = Integer.parseInt(args[3]);
		int sum;
			
		sum = data1+data2+data3;
		
		System.out.println("�Է��� ���ڿ�: " + res);
		System.out.println("������ ����: " + sum);
	}

}
