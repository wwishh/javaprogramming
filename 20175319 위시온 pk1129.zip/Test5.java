package pk1129;

interface Q1 {
	void a();
}

class T5 implements Q1 {
	public void a() {
		
		int score[] = { 56, 80, 100, 89, 45, 79, 34, 89, 90, 75 };
		char c;
		int sum = 0;
		double avg=0;
		
		for (int i = 0; i <= 9; i++) {
			sum += score[i];
		}
		
		avg = (double) sum / 10;

		if (avg >= 90 && avg <= 100)
			c = 'A';
		else if (avg >= 80 && avg <= 89)
			c = 'B';
		else if (avg >= 70 && avg <= 79)
			c = 'C';
		else if (avg >= 60 && avg <= 69)
			c = 'D';
		else
			c = 'F';
		System.out.println("����: " + sum + " ���: " + avg + " ����: " + c);

	}

}

public class Test5 {
	public static void main(String args[]) {
		T5 obj1 = new T5();

		obj1.a();
	}
}
