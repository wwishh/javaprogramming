package pk1129;

class T1 {
	int score[] = { 56, 80, 100, 89, 45, 79, 34, 89, 90, 75 };
	char c;
	int sum = 0;
	double avg;
}

class T2 extends T1 {
	void esum() {
		for (int i = 0; i <= 9; i++) {
			sum += score[i];
		}
		avg = (double) sum / 10;
	}

	void credit() {
		if (avg >= 90 && avg <= 100) {
			c = 'A';
		} else if (avg >= 80 && avg <= 89) {
			c = 'B';
		} else if (avg >= 70 && avg <= 79) {
			c = 'C';
		} else if (avg >= 60 && avg <= 69) {
			c = 'D';
		} else
			c = 'F';
	}

	void print() {
		System.out.println("����: " + sum + " ���: " + avg + " ����: " + c);
	}
}

public class Test3 {
	public static void main(String args[]) {
		T2 obj1 = new T2();

		obj1.esum();
		obj1.credit();
		obj1.print();
	}
}
