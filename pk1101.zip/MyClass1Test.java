package pk1101;

public class MyClass1Test {
	public static void main(String[] args){
		MyClass1 mc1 = new MyClass1();

		mc1.setName("�ϲ۰���");
	}
}
