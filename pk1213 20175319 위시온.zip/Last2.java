package pk1213;

import java.util.Scanner;

class G1{
	int num, cnt = 0, i;
	Scanner sc = new Scanner(System.in);
}
class G2 extends G1{
	void print(){
		System.out.println("����� �Է��ϼ���:");
	}
	void ecnt(){
		num = sc.nextInt();
		for (i = 1; i <= 100; i++) {
			if (i % num == 0) {
				System.out.format("%-10d", i);
				cnt++;
				if (cnt % 10 == 0) {
					System.out.println("");
				}
			}
		}
	}
	void print2(){
		System.out.println("\n[" + num + "]�� ����� ������ [" + cnt + "]�� �Դϴ�");
	}
}
public class Last2 {
	public static void main(String args[]) {
		G2 obj1 = new G2();
		
		obj1.print();
		obj1.ecnt();
		obj1.print2();
		
	}

}
