package pk1213;

import java.util.Scanner;

interface H1{
	void print();
	void ecnt();
	void print2();
}
class K1{
	int num, cnt = 0, i;
	Scanner sc = new Scanner(System.in);
}
class K2 extends K1 implements H1{
	public void print(){
		System.out.println("����� �Է��ϼ���:");
	}
	public void ecnt(){
		num = sc.nextInt();
		for (i = 1; i <= 100; i++) {
			if (i % num == 0) {
				System.out.format("%-10d", i);
				cnt++;
				if (cnt % 10 == 0) {
					System.out.println("");
				}
			}
		}
	}
	public void print2(){
		System.out.println("\n[" + num + "]�� ����� ������ [" + cnt + "]�� �Դϴ�");
	}
}
public class Last3 {
	public static void main(String args[]) {
		K2 obj1 = new K2();
		
		obj1.print();
		obj1.ecnt();
		obj1.print2();
		
	}

}
