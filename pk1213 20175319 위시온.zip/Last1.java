package pk1213;

class L1 {
	int data[] = { 2, 3, 5, 17, 20, 24, 25, 30, 31, 32 };
	int cnt = 0;
}

class L2 extends L1 {
	void ecnt() {
		for (int i = 0; i < data.length; i++) {
			if (data[i] % 2 == 0 && data[i] % 5 == 0) {
				System.out.format("%-10d", data[i]);
				cnt++;
			}
		}
	}

	void print() {
		System.out.println("\n������ : " + cnt);
	}
}

public class Last1 {
	public static void main(String args[]) {
		L2 obj1 = new L2();

		obj1.ecnt();
		obj1.print();
	}

}
