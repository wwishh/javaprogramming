package pk1108;

public class ConEx5 {
	......

	public static void main(String[] args) {
		ConEx5 obj = new ConEx5(10, 100, 8, 10);
		
		obj.eSumCnt();
		obj.ePrintData();
		obj.ePrintSumCnt();
	}
}
