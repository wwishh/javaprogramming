package pk1108;

public class ConEx4 {
	.....

	public static void main(String[] args) {
		ConEx4 obj = new ConEx4(6);
		
		obj.eSumCnt();
		obj.ePrintData();
		obj.ePrintSumCnt();
	}
}
