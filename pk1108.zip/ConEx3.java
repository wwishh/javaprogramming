package pk1108;

public class ConEx3 {
	.....
	
	public static void main(String[] args) 
	{
		ConEx3 obj1= new ConEx3();
		ConEx3 obj2= new ConEx3(90);
		ConEx3 obj3= new ConEx3(90, 78, 56);
		
		obj1.credit();
		obj1.print();
		
		obj2.credit();
		obj2.print();
		
		obj3.credit();
		obj3.print();
	}
}
