package pk1127;

abstract class AbsEx2 extends AbsEx1{					
	public int getA(){
		return a;
	}
	public abstract String getStr();
}
