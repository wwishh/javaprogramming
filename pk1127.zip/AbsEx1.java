package pk1127;

abstract class AbsEx1{
	int a = 100; 
	final String str = "abstract test"; 

	public String getStr(){  
		return str;
	}
	
	abstract public int getA();    
}
