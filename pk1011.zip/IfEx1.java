package pk1011;

public class IfEx1 {
	public static void main(String[] args) {

		if(args.length > 0){
			char c = args[0].charAt(0);
			String msg = null;

			if(c>='0' && c<='9')
				msg = "����";
			else if(c>='a' && c<='z')
				msg = "�ҹ���";
			else if(c>='A' && c<='Z')
				msg = "�빮��";
			else
				msg = "�����";

			System.out.println(msg);
		}
	}
}
