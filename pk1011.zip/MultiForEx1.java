package pk1011;

public class MultiForEx1 {
	public static void main(String[] args) {
		char ch = 65;
		int cnt=0;

		for(int i = 0 ; i <26 ; i++)
		{
			System.out.print(ch++ +"  ");
			cnt++;
			if(cnt%5 == 0)
				System.out.println();
		}
		System.out.println();
	}
}
