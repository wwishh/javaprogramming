package pk1011;

public class Do_WhileEx1 {
	public static void main(String[] args) {

		int su = 5;
		String str = "Java";

		do{
			System.out.println(str + (su-4));

		}while(su++ < 9); 
	}
}
