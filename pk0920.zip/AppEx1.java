package pk0920;

public class AppEx1 {
	public static void main(String[] args) 
	{
		int input, minute, second;
		int SEC_PER_MINUTE=60;
	
		input = Integer.parseInt(args[0]);
		
		minute = input / SEC_PER_MINUTE;	// �� ��
		second = input % SEC_PER_MINUTE;	// �� ��
	
		System.out.print("�Է��Ͻ� " + input +  "�ʴ� ");
	  	System.out.print( minute + "�� " + second + "�� �Դϴ�." );
	}
}
