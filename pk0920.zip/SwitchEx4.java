package pk0920;

public class SwitchEx4 {
	public static void main(String[] args) {
		int d1,d2,d3;
		int sum;
		double avg;
		char c;
		
		d1 = Integer.parseInt(args[0]);
		d2 = Integer.parseInt(args[1]);
		d3 = Integer.parseInt(args[2]);
	
		sum = d1+ d2+ d3;
		avg = sum/3.0;
		
		switch((int)avg/10)
		{
			case 10:
			case 9: c='A';break;
			case 8: c='B'; break;
			case 7: c='C'; break;
			case 6: c='D'; break;
			default :
				c = 'F';
		}
		System.out.print("�Է��Ͻ� �����ʹ�  "  + d1 + " " +  d2 + " " + d3 +"�̰�, ");
		System.out.println("���� "  + sum + ", ����� " + avg + ", ������ " + c  +"�Դϴ�.");
	}
}
