package pk0920;

public class SwitchEx3 {
	public static void main(String[] args) {
		int d1,d2,d3;
		
		d1 = Integer.parseInt(args[0]);
		d2 = Integer.parseInt(args[1]);
		d3 = Integer.parseInt(args[2]);
	
		System.out.println("�Է��Ͻ� �����ʹ�  "  + d1 + " " +  d2 + " " + d3 +"�Դϴ�.");
	}
}
